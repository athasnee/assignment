﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StudentEntities;
using StudentExceptions;
using System.Data;
using System.Data.Common;
using System.Windows;

namespace StudentDal
{
    public class StudDal
    {
        public bool AddStudDAL(Student newStud)
        {
            bool StudAdded = false;
           
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "AddStudent";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@StudName";
                param.DbType = DbType.String;
                param.Value = newStud.StudName;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@City";
                param.DbType = DbType.String;
                param.Value = newStud.City;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@CourseEnroll";
                param.DbType = DbType.String;
                param.Value = newStud.CourseEnroll;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@DOAd";
                param.DbType = DbType.DateTime;
                param.Value = newStud.DOAd;
                command.Parameters.Add(param);

                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    StudAdded = true;
                
            }
            catch (DbException ex)
            {
                string errormessage;

                switch (ex.ErrorCode)
                {
                    case -2146232060:
                        errormessage = "Database Does NotExists Or AccessDenied";
                        break;
                    default:
                        errormessage = ex.Message;
                        break;
                }
                throw new StudException(errormessage);
            }
            return StudAdded;

        }

        public List<Student> GetAllStudentsDAL()
        {
            List<Student> studList = null;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "GetStudent";



                DataTable dataTable = DataConnection.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    studList = new List<Student>();
                    for (int rowCounter = 0; rowCounter < dataTable.Rows.Count; rowCounter++)
                    {
                        Student stud = new Student();
                        stud.StudId = (int)dataTable.Rows[rowCounter][0];
                        stud.StudName = (string)dataTable.Rows[rowCounter][1];
                        stud.City = (string)dataTable.Rows[rowCounter][2];
                        stud.CourseEnroll = (string)dataTable.Rows[rowCounter][3];
                        stud.DOAd = (DateTime)dataTable.Rows[rowCounter][4];
                        studList.Add(stud);
                    }
                }
            }
            catch (DbException ex)
            {
                throw new StudException(ex.Message);
            }
            return studList;
        }

        public Student SearchStudDAL(int searchStudentId)
        {
            Student searchStud = null;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "SearchStudent";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@StudId";
                param.DbType = DbType.Int32;
                param.Value = searchStudentId;
                command.Parameters.Add(param);

                DataTable dataTable = DataConnection.ExecuteSelectCommand(command);
                if (dataTable.Rows.Count > 0)
                {
                    searchStud = new Student();
                    searchStud.StudId = (int)dataTable.Rows[0][0];
                    searchStud.StudName = (string)dataTable.Rows[0][1];
                    searchStud.City = (string)dataTable.Rows[0][2];
                    searchStud.CourseEnroll = (string)dataTable.Rows[0][3];
                    searchStud.DOAd = (DateTime)dataTable.Rows[0][4];


                }
            }
            catch (DbException ex)
            {
                throw new StudException(ex.Message);
            }
            return searchStud;
        }

        public bool UpdateStudDAL(Student updateStud)
        {
            bool StudUpdated = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "UpdateStudent";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@StudId";
                param.DbType = DbType.Int32;
                param.Value = updateStud.StudId;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@StudName";
                param.DbType = DbType.String;
                param.Value = updateStud.StudName;
                command.Parameters.Add(param);


                param = command.CreateParameter();
                param.ParameterName = "@City";
                param.DbType = DbType.String;
                param.Value = updateStud.City;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@CourseEnroll";
                param.DbType = DbType.String;
                param.Value = updateStud.CourseEnroll;
                command.Parameters.Add(param);

                param = command.CreateParameter();
                param.ParameterName = "@DOAd";
                param.DbType = DbType.String;
                param.Value = updateStud.DOAd;
                command.Parameters.Add(param);



                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)

                    StudUpdated = true;
            }
            catch (DbException ex)
            {
                throw new StudException(ex.Message);
            }
            return StudUpdated;

        }

        public bool DeleteStudDAL(int deleteStudId)
        {
            bool StudDeleted = false;
            try
            {
                DbCommand command = DataConnection.CreateCommand();
                command.CommandText = "DeleteStudent";

                DbParameter param = command.CreateParameter();
                param.ParameterName = "@StudId";
                param.DbType = DbType.Int32;
                param.Value = deleteStudId;
                command.Parameters.Add(param);

                int affectedRows = DataConnection.ExecuteNonQueryCommand(command);

                if (affectedRows > 0)
                    StudDeleted = true;
            }
            catch (DbException ex)
            {
                throw new StudException(ex.Message);
            }
            return StudDeleted;

        }




    }

}
