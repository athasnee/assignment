﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentEntities
{
    public class Student
    {
        public int StudId { get; set; }
        public string StudName { get; set; }
        public string City { get; set; }
        public string CourseEnroll { get; set; }
        public DateTime DOAd  { get; set; }

    }
}
