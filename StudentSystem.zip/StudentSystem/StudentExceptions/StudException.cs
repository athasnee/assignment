﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentExceptions
{
    public class StudException: ApplicationException
    {
        public StudException(): base()
        {
        }

        public StudException(string message)
            : base(message)
        {
        }
        public StudException(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }
}
