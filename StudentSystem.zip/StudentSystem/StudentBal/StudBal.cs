﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StudentEntities;
using StudentExceptions;
using StudentDal;
using System.Windows;

namespace StudentBal
{
    public class StudBal
    {
        private static bool ValidateStud(Student stud)
        {
            
            StringBuilder sb = new StringBuilder();
            bool validGuest = true;
            if (stud.StudName == string.Empty)
            {
                validGuest = false;
                sb.Append(Environment.NewLine + "Student Name Required");

            }
            if (stud.City == string.Empty)
            {
                validGuest = false;
                sb.Append(Environment.NewLine + "Student Name Required");

            }
            if (stud.CourseEnroll == string.Empty)
            {
                validGuest = false;
                sb.Append(Environment.NewLine + "Student Name Required");

            }
            if (validGuest == false)
                throw new StudException(sb.ToString());
            return validGuest;
        }

        public static bool AddStudBL(Student newStud)
        {
            bool StudAdded = false;
            try
            {
                if (ValidateStud(newStud))
                {
                    

                    StudDal studDAL = new StudDal();
                    StudAdded = studDAL.AddStudDAL(newStud);
                }
            }
            catch (StudException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return StudAdded;
           
        }

        public static Student SearchGuestBL(object searchGuestID)
        {
            throw new NotImplementedException();
        }

        public static List<Student> GetAllStudBL()
        {
            List<Student> StudList = null;
            try
            {
                StudDal studDAL = new StudDal();
                StudList = studDAL.GetAllStudentsDAL();
            }
            catch (StudException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return StudList;
        }

        public static Student SearchStudBL(int searchStudID)
        {
            Student searchStud = null;
            try
            {
                StudDal studDAL = new StudDal();
                searchStud = studDAL.SearchStudDAL(searchStudID);
            }
            catch (StudException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchStud;

        }

        public static bool UpdateStudBL(Student updateStud)
        {
            bool StudUpdated = false;
            try
            {
                if (ValidateStud(updateStud))
                {
                    StudDal studDAL = new StudDal();
                    StudUpdated = studDAL.UpdateStudDAL(updateStud);
                }
            }
            catch (StudException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return StudUpdated;
        }

        public static bool DeleteStudBL(int deleteStudID)
        {
            bool StudDeleted = false;
            try
            {
                if (deleteStudID > 0)
                {
                    StudDal studDAL = new StudDal();
                    StudDeleted = studDAL.DeleteStudDAL(deleteStudID);
                }
                else
                {
                    throw new StudException("Invalid Student ID");
                }
            }
            catch (StudException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return StudDeleted;
        }

    }

}
