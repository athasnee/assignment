﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using StudentEntities;
using StudentExceptions;
using StudentBal;

namespace StudentWpf
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public object searchStudID;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void textBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
        
        private void button_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                int searchStudID = Convert.ToInt32(txtId.Text);
                Student searchStud = StudBal.SearchStudBL(searchStudID);
                if (searchStud != null)
                {

                    txtName.Text = searchStud.StudName;
                    txtCity.Text = searchStud.City;
                    txtCourse.Text = searchStud.CourseEnroll;
                    DOA.Text = searchStud.DOAd.ToString();


                    label5.Content = "Student details available";
                }
                else
                    label5.Content = "No Students available";

            }
            catch (StudException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int deleteStudId = Convert.ToInt32(txtId.Text);
                Student deleteStud = StudBal.SearchStudBL(deleteStudId);
                if (deleteStud != null)
                {
                    bool studdeleted = StudBal.DeleteStudBL(deleteStudId);
                    if (studdeleted)
                        label5.Content = "Student Deleted";
                    else
                        label5.Content = "Student not Deleted ";
                }
                else
                {
                    label5.Content = "No Student Details Available";
                }


            }
            catch (StudException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int updateStudId = Convert.ToInt32(txtId.Text);
                Student updatedStud = StudBal.SearchStudBL(updateStudId);
                if (updatedStud != null)
                {
                    updatedStud.StudName = txtName.Text;
                    updatedStud.City = txtCity.Text;
                    updatedStud.CourseEnroll = txtCourse.Text;
                    updatedStud.DOAd = Convert.ToDateTime(DOA.Text);
                    bool studUpdated =StudBal.UpdateStudBL(updatedStud);
                    if (studUpdated)
                        label5.Content = "Student Details Updated";
                    else
                        label5.Content = "Student Details not Updated";
                }

            }
            catch (StudException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void btnGetAll_Click(object sender, RoutedEventArgs e)
        {
            List<Student> studList = StudBal.GetAllStudBL();
            dataGrid.ItemsSource = studList;
        }

        private void dataGrid_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {
            Student sObj = (Student)(object)dataGrid.SelectedItem;
            txtId.Text = sObj.StudId.ToString();
            txtName.Text = sObj.StudName;
            txtCity.Text = sObj.City;
            txtCourse.Text = sObj.CourseEnroll;
            DOA.Text = sObj.DOAd.ToLongDateString();

        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Student sobj = new Student();
              
                //sobj.StudId = Convert.ToInt32(txtId.Text);
                sobj.StudName = txtName.Text;
                sobj.City = txtCity.Text;
               
                sobj.CourseEnroll = txtCourse.Text;
                sobj.DOAd = Convert.ToDateTime(DOA.Text);

                
               bool StudAdded= StudBal.AddStudBL(sobj);
               
                if (StudAdded)
                {
                    MessageBox.Show("Sucessfully added");
                }
                else
                {
                    MessageBox.Show("Not Added");
                }
            }
            catch (Exception ex)
            {
                

                MessageBox.Show(ex.Message);
            }


        }
    }
}
