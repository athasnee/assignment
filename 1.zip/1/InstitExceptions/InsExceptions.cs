﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InstitExceptions
{
    public class InsExceptions: ApplicationException
    {
        public InsExceptions()
            : base()
        {
        }

        public InsExceptions(string message)
            : base(message)
        {
        }
        public InsExceptions(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }
}
