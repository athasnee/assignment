﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IstitEntities;
using InstitDAL;
using InstitExceptions;

namespace InstitBAL
{
    public class Insbal
    {
        public static List<Student> GetcourseBL()
        {
            List<Student> projlist = null;
            try
            {
                Insdal projbal = new Insdal();
                projlist = projbal.getpolicyname();
            }
            catch (InsExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return projlist;
        }

        public static List<Student> GetBranch()
        {
            List<Student> branchlist = null;
            try
            {
                Insdal projbal = new Insdal();
                branchlist = projbal.getcityname();
            }
            catch (InsExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return branchlist;
        }
        public static bool Addstud(Student newproj)
        {
            bool projAdded = false;
            try
            {

                Insdal proj = new Insdal();
                projAdded = proj.addproj(newproj);

            }
            catch (InsExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return projAdded;
        }

        public static Student SearchprojBL(string searchname)
        {
            Student searchstudname = null;
            try
            {
                Insdal projdAL = new Insdal();
                searchstudname = projdAL.Searchstud(searchname);
            }
            catch (InsExceptions ex)
            {
                
                throw ex;
            }
            catch (Exception ex)
            {
              
                throw ex;
            }
            return searchstudname;

        }
        public static bool UpdateProjBL(Student updateproj)
        {
            bool studUpdated = false;
            try
            {
                
                {
                    Insdal projdAL = new Insdal();
                    studUpdated = projdAL.Updatestudent(updateproj);
                }
            }
            catch (InsExceptions ex)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return studUpdated;
        }
        public static bool DeleteProjBL(string deleteProjname)
        {
            bool projDeleted = false;
            try
            {
                
                    Insdal guestdAL = new Insdal();
                    projDeleted = guestdAL.DeleteStudent(deleteProjname);
             
               
            }
            catch (InsExceptions)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return projDeleted;
        }


    }
}
