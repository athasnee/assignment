﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using InstitBAL;
using InstitExceptions;
using IstitEntities;
using System.Windows.Forms;

namespace Institutesolution
{
    public partial class Registrationform : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                List<Student> corsname = Insbal.GetcourseBL();

                //foreach (var item in corsname)
                //{
                //    DropDownList2.Items.Add(item.CorseName);
                //}

                DropDownList2.DataSource = corsname;
                DropDownList2.DataTextField = "CorseName";
                DropDownList2.DataValueField = "CorseID";
                DropDownList2.DataBind();


                List<Student> brname = Insbal.GetBranch();
                DropDownList1.DataSource = brname;
                DropDownList1.DataTextField = "City";
                DropDownList1.DataValueField = "InstiID";
                DropDownList1.DataBind();
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
               Student newProj = new Student();

                //newProj.projID = Convert.ToInt32(txtprojd.Text);

                newProj.StudName = textbox1.Text;
                newProj.DOB = Convert.ToDateTime(TextBox2.Text);
               
                newProj.CorseID = Convert.ToInt32(DropDownList2.SelectedItem.Value);
                newProj.InstiID = Convert.ToInt32(DropDownList1.SelectedItem.Value);
                bool projAdded =Insbal.Addstud(newProj);

                if (projAdded)
                    Label8.Text = "Student Added";
                  
                else
                    Label8.Text = "Student not Added";
            }
            catch (Exception ex)
            {
                Label8.Text = ex.ToString();
            }
        }

        protected void Unnamed1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void TextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            try
            {
                string searchname;
                searchname = textbox1.Text;
                Student searchstud = Insbal.SearchprojBL(searchname);
                if (searchname != null)
                {
                    textbox1.Text = searchstud.StudName;
                    TextBox2.Text = searchstud.DOB.ToString();
                    DropDownList1.Text = searchstud.InstiID.ToString();
                    DropDownList2.Text = searchstud.CorseID.ToString();

                }
                else
                {
                    MessageBox.Show("student name not found");
                }
            }
            catch (InsExceptions ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }

        // update
        protected void Button3_Click(object sender, EventArgs e)
        {

            string studname;
            studname = textbox1.Text;
           Student updatedstud = Insbal.SearchprojBL(studname);
            if (updatedstud != null)
            {
                
                updatedstud.DOB =Convert.ToDateTime (TextBox2.Text);
                updatedstud.CorseID = Convert.ToInt32(DropDownList2.SelectedItem.Value);
                updatedstud.InstiID = Convert.ToInt32(DropDownList1.SelectedItem.Value);
                bool guestUpdated = Insbal.UpdateProjBL(updatedstud);
                if (guestUpdated)
                    Label8.Text="student Details Updated";
                else
                    Label8.Text = "student Details not Updated ";
            }
        }

        //delete
        protected void Button4_Click(object sender, EventArgs e)
        {
            try
            {
                string studname;
                studname = textbox1.Text;
                Student deleteproj = Insbal.SearchprojBL(studname);
                if (deleteproj != null)
                {
                    bool projdeleted = Insbal.DeleteProjBL(studname);
                    if (projdeleted)
                        MessageBox.Show("student Deleted");
                    else
                        MessageBox.Show("student not Deleted ");
                }
                else
                {
                    MessageBox.Show("No strudnets Available");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }
    }
    }
