﻿using System;
using BankBEntities;

namespace BankClasslib
{
    public  delegate void Onbalancechange(CAccountsEnt accobjent);
   // [CLSCompliant(true)]
   public class CSavingAccounts:CAccounts, ICalcInterest
    {
        #region Field
        private decimal _balance;
        public event Onbalancechange onbalchange;
        Onbalancechange balancechange = new Onbalancechange(SMSAlert);

        #endregion

        #region Property

        public decimal BALANCE { get { return _balance; } }
        #endregion

        #region Method

        public override void mDeposit(BankBEntities.CAccountsEnt accobj)
        {
            _balance += accobj.AMOUNT;
            balancechange(accobj);
            if (onbalchange != null)
            {
                onbalchange(accobj);
            }


        }

      
        public override void mWithdraw(BankBEntities.CAccountsEnt accobj)
        {
            if (_balance > 5000)
            {
                _balance -= accobj.AMOUNT;
                balancechange(accobj);
                if (onbalchange != null)
                {
                    onbalchange(accobj);
                }
            }
            else
            {
                throw new InSufficientFundException("You have insufficient amount in your account");
            }
        }

        public decimal interestcalc(int time, float rate, decimal amt)
        {
            return ((decimal)time * (decimal) rate * amt);
        }

       public static void SMSAlert(CAccountsEnt accentobj)
       {
           Console.WriteLine("SMS Alert");
           Console.WriteLine("Account No {0} has changed in balance",accentobj.ACCOUNTNO );
       }
        #endregion

        #region Constructor

        public CSavingAccounts()
        {
           
        }
        public CSavingAccounts(CAccountsEnt entobj)
        {
            _balance = entobj.AMOUNT;
        }
        #endregion
        
    }
}
