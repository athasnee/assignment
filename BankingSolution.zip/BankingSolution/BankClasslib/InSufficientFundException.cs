﻿using System;

namespace BankClasslib
{
    public class InSufficientFundException:ApplicationException
    {
        #region Constructor

        public InSufficientFundException():base()
        {

        }

        public InSufficientFundException(String message):base(message)
        {

        }

        public InSufficientFundException(String message, Exception innerException):base(message, innerException)
        {

        }
        #endregion
    }
}
