﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day1
{
    class CnewClass
    {
        #region Data Members
        #endregion
        #region Properties
        #endregion
        #region Methods
        #endregion
        #region Constructor
        #endregion
    }
}
