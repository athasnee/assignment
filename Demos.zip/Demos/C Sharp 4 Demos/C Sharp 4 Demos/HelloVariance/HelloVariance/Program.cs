﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloVariance
{
    class Program
    {
        static void Main(string[] args)
        {
            //            There is no reason this shouldn’t work, as the code is safe. By using the IEnumerable interface,
            //Employees are only ever returned in the output position, and you cannot do any reassignment. So the new
            //variance changes are very much fixing a problem that should never have existed.

            IList<Manager> imanagers = new List<Manager>();
            imanagers.Add(new Manager() { EmployeeId = 101 });
            imanagers.Add(new Manager() { EmployeeId = 102 });
            imanagers.Add(new Manager() { EmployeeId = 103 });

            IEnumerable<Employee> iemployees = imanagers;

            foreach (Manager m in iemployees)
                Console.WriteLine(m.EmployeeId);

            Console.ReadKey();
            //This will not work in C# 3.0 but will work in C# 4.0 as IEnumerable interface has changed in 4.0
            //the IEnumerable<T> interface now has the out keyword in its parameter list, 
            //which enables us to use a more specific class (Manager) when a more general class(Employee) 
            //should be used.
            //The out keyword tells the compiler that Employee can only ever be returned (in the output position)
            //which keeps the compiler happy, because IEnumerable contains no way for you to add
            //objects to it after IEnumerable is declared
            //The term used for this is "covariance", and it allows an item to be treated as its supertype. 

        }
    }
    public class Employee
    {
        public int EmployeeId { get; set; }
    }
    public class Manager : Employee
    {
        public double Perks { get; set; }
        public double Get()
        {
            return Perks;
        }
    }
}
