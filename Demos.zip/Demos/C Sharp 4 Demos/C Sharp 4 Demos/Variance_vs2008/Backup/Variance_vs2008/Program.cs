﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Variance_vs2008
{
    class Program
    {
        static void Main(string[] args)
        {
            //This will not work in C# 3.0 but will work in C# 4.0
            IList<Manager> imanagers = new List<Manager>();
            IEnumerable<Employee> iemployees = imanagers;

            EmployeeComparer empcomparer = new EmployeeComparer();

             List<Manager> managerlist = new List<Manager>();
            managerlist.Add(new Manager(202, 20, 10000));
            managerlist.Add(new Manager(203, 40, 10000));
            managerlist.Add(new Manager(204, 30, 10000));
            managerlist.Add(new Manager(205, 10, 10000));

            //Doesn't work prior to .net 4
            managerlist.Sort(empcomparer);

            managerlist.ForEach(e=> Console.WriteLine(e.EmployeeId.ToString() + "-" + e.DepartmentId.ToString()));
        }
    }
    public class EmployeeComparer : IComparer<Employee>
    {

        public int Compare(Employee x, Employee y)
        {
            if (x.DepartmentId > y.DepartmentId) return 1;
            if (x.DepartmentId == y.DepartmentId) return 0;
            return -1;
        }
    }
}
