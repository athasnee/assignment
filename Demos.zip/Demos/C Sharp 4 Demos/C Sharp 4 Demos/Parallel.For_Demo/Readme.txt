﻿One of the Parallel Extensions is the Parallel.For method which runs the for loop using multiple threads.

Comment/Uncomment the ParallelMethod() or NonParallelMethod() invokation to see the difference in speed when executing the For statement.

            ParallelMethod();
            NonParallelMethod();
